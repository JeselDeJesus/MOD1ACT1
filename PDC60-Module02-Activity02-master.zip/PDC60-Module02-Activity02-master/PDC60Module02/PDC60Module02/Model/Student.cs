﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PDC60Module02.Model
{
    class Student
    {
        public string Subjectcode { get; set; }
        public string SubjectTitle { get; set; }
        public int Unit { get; set; }
    }
}
