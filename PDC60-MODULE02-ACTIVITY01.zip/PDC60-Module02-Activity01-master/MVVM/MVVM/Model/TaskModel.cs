﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MVVM.Model
{
    class TaskModel
    {
        public String Subjectcode { get; set; }
        public String SubjectTitle { get; set; }
        public int Unit { get; set; }

    }
}
